% Verileri yükleme
data = load('veriler_kalp.xlsx');

% Giriş ve çıktı verilerini ayırma
inputs = data.inputs;
targets = data.targets;

% Sinir ağı oluşturma
net = feedforwardnet([10 10 1]);

% Ağı eğitme
net = train(net, inputs, targets);

% Tahmin yapma
predictions = net(inputs);

% Doğruluk hesaplama
accuracy = mean(round(predictions) == targets);

% Sonuçları yazdırma
disp(['Doğruluk: ' num2str(accuracy)]);
